export type UserRole = 'CLIENTE' | 'VENDEDOR' | 'MASTER';

export type ModalityType = 'DELIVERY' | 'RETIRADA' | 'EXPERIMENTAÇÃO' | 'AGENDAMENTO';

export type OrderStatus = 'Aguardando' | 'Confirmado' | 'Em Preparo' | 'Em Rota' | 'Pronto para Retirada' | 'Concluído' | 'Cancelado' | 'Sem Estoque';

export type ItemType = 'PRODUTO_FISICO' | 'SERVICO' | 'INSTALACAO' | 'MANUTENCAO';

export interface ProfessionalReference {
  id?: string;
  name: string;
  phone: string;
  relationshipOrRole: string; // Ex: "Cliente Residencial", "Síndico Condomínio", "Comércio Parceiro"
  notes?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  details: string;
  ipAddress: string;
  device: string;
  timestamp: string;
}

export interface CustomerAddress {
  id: string;
  label: string; // Ex: "Casa", "Trabalho", "Sítio / Papucaia"
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zipCode?: string;
  referencePoint?: string;
  deliveryInstructions?: string;
  isDefault?: boolean;
}

export interface VipMeasurements {
  topSize?: string; // PP, P, M, G, GG, XGG, G1, G2
  bottomSize?: string; // 34 a 56
  shoeSize?: string; // 33 a 46
  height?: string; // Ex: 1.68m
  weight?: string; // Ex: 65kg
  preferredFit?: 'Ajustado' | 'Normal' | 'Solto' | 'Oversized';
  favoriteColors?: string[];
  avoidColors?: string[];
  stylePreferences?: string[]; // Ex: ["Casual", "Social", "Esportivo", "Moda Praia"]
  fitNotes?: string;
}

export interface CustomerPreferences {
  receiveWhatsApp: boolean;
  receiveEmail: boolean;
  receiveSms: boolean;
  receivePromoAlerts: boolean;
  preferredModality?: 'DELIVERY' | 'RETIRADA' | 'EXPERIMENTAÇÃO';
  dietaryRestrictions?: string;
  favoriteCategories?: string[];
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface User {
  id: string;
  name: string;
  nickname?: string;
  email: string;
  phone: string;
  secondaryPhone?: string;
  role: UserRole;
  password?: string;
  city: string;
  address?: string;
  neighborhood?: string;
  merchantId?: string; // If role is VENDEDOR, links to their store
  avatar?: string;
  cpf?: string;
  idDocument?: string; // RG / Identidade Oficial
  birthDate?: string;
  gender?: 'Feminino' | 'Masculino' | 'Não-binário' | 'Outro' | 'Prefiro não informar';
  addresses?: CustomerAddress[];
  references?: ProfessionalReference[];
  measurements?: VipMeasurements;
  preferences?: CustomerPreferences;
  emergencyContact?: EmergencyContact;
  generalNotes?: string;
  isEmailVerified?: boolean;
  needsPasswordChange?: boolean;
  twoFactorEnabled?: boolean;
  status?: 'active' | 'suspended' | 'blocked';
  statusReason?: string;
  lastLogin?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  badge?: string;
  image?: string;
  description?: string;
}

export interface ProductVariation {
  name: string; // e.g. "Tamanho", "Cor", "Sabor"
  options: string[]; // e.g. ["P", "M", "G"], ["Vermelho", "Preto"]
}

export interface Product {
  id: string;
  merchantId: string;
  merchantName: string;
  merchantCategory: string;
  merchantRating: number;
  merchantAddress: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: string;
  subcategory?: string;
  stock: number;
  itemType?: ItemType; // PRODUTO_FISICO | SERVICO | INSTALACAO | MANUTENCAO
  executionLocation?: 'DOMICILIO' | 'ESTABELECIMENTO' | 'AMBOS';
  warrantyDays?: number;
  serviceEstimateTime?: string;
  estimatedDuration?: string;
  isQuoteBased?: boolean;
  availableModalities: ('DELIVERY' | 'RETIRADA' | 'EXPERIMENTAÇÃO' | 'AGENDAMENTO')[];
  featured?: boolean;
  isNewArrival?: boolean;
  isDeal?: boolean;
  isPopular?: boolean;
  rating: number;
  reviewsCount: number;
  variations?: ProductVariation[];
  specs?: { [key: string]: string };
  // Novas configurações de Taxa, PIX e Ações por Categoria
  advanceFeeRequired?: boolean;
  advanceFeeAmount?: number; // Valor da taxa de adiantamento em R$
  pixKey?: string; // Chave PIX do lojista
  pixKeyType?: 'CPF' | 'CNPJ' | 'CELULAR' | 'TELEFONE' | 'EMAIL' | 'ALEATORIA';
  pixBeneficiaryName?: string;
  furnitureActionType?: 'COMPRAR_APENAS' | 'ALUGAR_APENAS' | 'COMPRAR_E_ALUGAR' | 'BUY' | 'RENT' | 'BOTH'; // Móveis e locações
  rentPrice?: number;
  rentPeriod?: 'DIARIA' | 'MENSAL' | 'EVENTO' | 'DIA' | 'SEMANA' | 'MES';
  vehicleActionType?: 'RESERVAR_E_VISITAR' | 'RESERVAR_APENAS' | 'VISITAR_APENAS' | 'BOTH' | 'RESERVE' | 'VISIT'; // Veículos
  vehicleYear?: string;
  vehicleKm?: string;
  status: 'active' | 'paused' | 'draft' | 'archived';
  createdAt: string;
}

export interface ProfessionalCredentials {
  registrationNumber?: string; // Ex: "CRM-RJ 98.421", "CRO-RJ 48920", "CREA-RJ 2021190", "CRP 05/12345"
  registrationEntity?: string; // Ex: "Conselho Regional de Odontologia", "CREA", "OAB", "MEI"
  experienceYears?: number; // Ex: 12 anos de atuação em Cachoeiras de Macacu
  specializations?: string[]; // Ex: ["Implantodontia", "Ortodontia", "Elétrica de Alta Tensão"]
  certifications?: string[]; // Ex: ["Certificação Apple", "NR10 Segurança Elétrica", "Pós-Graduação UFF"]
  warrantyInfo?: string; // Ex: "90 dias de garantia legal com emissão de nota fiscal de serviços"
  guaranteeDays?: number;
}

export interface ServicePricingTable {
  hourlyRate?: number; // R$ / hora (avulso, consultas, pequenos reparos)
  dailyRate?: number; // R$ / diária (dia de trabalho de 8h, plantão, evento)
  monthlyRate?: number; // R$ / mensalidade (reforço escolar mensal, planos de estética recorrente, manutenção predial)
  customQuoteDescription?: string; // Informações para orçamentos sob medida
  pricingNotes?: string; // Ex: "Materiais e peças orçados separadamente. Deslocamento incluso para toda Cachoeiras de Macacu."
}

export interface MerchantAvailableSlot {
  id: string;
  dayOfWeek: string; // "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"
  time: string; // "09:00", "10:30", etc.
  isAvailable: boolean; // true = vaga livre, false = ocupado/bloqueado
  period: 'MANHA' | 'TARDE' | 'NOITE';
  professionalName?: string;
}

export interface MerchantScheduleConfig {
  workingDays: {
    day: string;
    isOpen: boolean;
    startHour: string;
    endHour: string;
    lunchStart?: string;
    lunchEnd?: string;
  }[];
  slotDurationMinutes: number; // 30, 45, 60, 90 min
  serviceExecutionModalities: ('ESTABELECIMENTO' | 'DOMICILIO' | 'ONLINE')[];
  advanceNoticeHours: number; // Ex: 2 horas de antecedência
  customSlots?: MerchantAvailableSlot[];
}

export interface MerchantServiceResponse {
  status: 'PENDENTE' | 'CONFIRMADO' | 'REAGENDADO' | 'RECUSADO' | 'CONCLUIDO';
  responseMessage: string; // Resposta oficial escrita pelo lojista/médico/professor
  merchantAuthorName: string; // Nome do profissional que respondeu
  respondedAt: string; // Data/Hora da resposta
  instructionsForCustomer?: string; // Ex: "Chegar 10 minutos antes com documento e exames anteriores"
  confirmedDate?: string;
  confirmedTime?: string;
  confirmedLocation?: string;
  confirmedPrice?: number;
  pricingType?: 'HORA' | 'DIARIA' | 'MENSAL' | 'SERVICO_FIXO' | 'ORCAMENTO';
}

export interface ServiceItem {
  id: string;
  merchantId: string;
  merchantName: string;
  merchantCategory: string;
  merchantRating: number;
  merchantAddress: string;
  title: string;
  description: string;
  price: number;
  durationMinutes: number;
  category: string;
  subcategory?: string;
  itemType?: ItemType;
  image: string;
  professionals: string[];
  availableDays: string[];
  timeSlots: string[];
  pricingTable?: ServicePricingTable;
  credentials?: ProfessionalCredentials;
  executionLocation?: 'ESTABELECIMENTO' | 'DOMICILIO' | 'ONLINE' | 'AMBOS';
  status: 'active' | 'paused' | 'archived';
}

export interface StoreMerchant {
  id: string;
  name: string;
  ownerName: string;
  email: string;
  phone: string;
  cnpjOrCpf: string;
  idDocument?: string; // RG / Documento de Identidade Obrigatório
  category: string;
  subcategory?: string;
  description: string;
  address: string;
  street?: string;
  number?: string;
  complement?: string;
  neighborhood: string;
  city: string;
  zipCode?: string;
  references?: ProfessionalReference[]; // Referências Obrigatórias
  credentials?: ProfessionalCredentials; // Registro profissional (CRM, CRO, CREA etc.)
  pricingTable?: ServicePricingTable; // Preço por hora, dia e mês
  scheduleConfig?: MerchantScheduleConfig; // Agenda com dias e horas vagas
  isServiceProvider?: boolean;
  offeredItemTypes?: ItemType[];
  isVerifiedProvider?: boolean;
  logo: string;
  banner?: string;
  gallery?: string[];
  rating: number;
  reviewsCount: number;
  isOpen: boolean;
  openingHours: string;
  deliveryFee: number;
  deliveryTimeEstimate: string;
  supportsPickup: boolean;
  supportsTrial: boolean;
  supportsAppointments: boolean;
  commissionRate?: number; // In percent (e.g. 5, 8, 10)
  status: 'approved' | 'pending' | 'rejected' | 'suspended' | 'blocked';
  statusReason?: string;
  submittedAt: string;
  updatedAt?: string;
}

export interface Order {
  id: string;
  code: string; // e.g. "RET-8X42K9" or "DEL-9912A"
  orderNumber?: string; // e.g. "#58291"
  securityCode?: string; // Código único de segurança / negociação (ex: "K7P4X9")
  clientVerified?: boolean; // Se o cliente validou via SMS/WhatsApp
  verificationPhoneCode?: string; // Código enviado no SMS/WhatsApp (ex: "482913")
  verificationChannel?: 'WHATSAPP' | 'SMS';
  customerEmail?: string;
  customerCpf?: string;
  termsAccepted?: boolean;
  stockConfirmationStatus?: 'PENDING_STORE_CONFIRMATION' | 'STOCK_CONFIRMED' | 'OUT_OF_STOCK' | 'EXPIRED';
  stockConfirmationExpiresAt?: string; // 15 minutos para a loja confirmar
  reservationExpiresAt?: string; // 30 minutos de reserva garantida
  paymentNegotiationNote?: string; // Negociação direta cliente + loja
  userId: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  merchantId: string;
  merchantName: string;
  type: 'PRODUTO' | 'SERVICO';
  items: {
    productId: string;
    productName: string;
    productImage: string;
    quantity: number;
    price: number;
    selectedVariation?: { [key: string]: string };
  }[];
  serviceDetails?: {
    serviceId: string;
    serviceTitle: string;
    professional: string;
    scheduledDate: string;
    scheduledTime: string;
    serviceLocation?: 'ESTABELECIMENTO' | 'DOMICILIO' | 'ONLINE';
    pricingTypeSelected?: 'HORA' | 'DIARIA' | 'MENSAL' | 'SERVICO_FIXO' | 'ORCAMENTO';
    customerNotes?: string;
    merchantResponse?: MerchantServiceResponse;
  };
  modality: ModalityType;
  status: OrderStatus;
  totalAmount: number;
  deliveryFee?: number;
  pickupCode?: string; // e.g. "RET-A8K9X2"
  trialDetails?: {
    date: string;
    time: string;
    notes?: string;
  };
  pickupValidatedAt?: string;
  internalNotes?: string;
  cancellationReason?: string;
  assignedDriver?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SystemSettings {
  maintenanceMode: boolean;
  systemBroadcastAlert: string;
  broadcastAlertActive: boolean;
  globalCommissionRate: number;
  allowNewRegistrations: boolean;
  autoApproveMerchants: boolean;
  defaultDeliveryFeeMacacu: number;
  vipTrialMaxDays: number;
  vipTrialSecurityDepositRequired: boolean;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  imageUrl: string;
  bgColor: string;
  actionText: string;
  categoryFilter?: string;
}

export type NotificationChannel = 'WHATSAPP' | 'SMS' | 'EMAIL' | 'PUSH';
export type NotificationStatus = 'SENT' | 'DELIVERED' | 'FAILED' | 'PENDING';
export type NotificationEventType =
  | 'ORDER_PLACED'
  | 'ORDER_CONFIRMED'
  | 'ORDER_PREPARING'
  | 'ORDER_DISPATCHED'
  | 'ORDER_READY_PICKUP'
  | 'ORDER_COMPLETED'
  | 'ORDER_CANCELLED'
  | 'TRIAL_REQUESTED'
  | 'TRIAL_CONFIRMED'
  | 'TRIAL_REMINDER'
  | 'SERVICE_BOOKED'
  | 'SERVICE_CONFIRMED'
  | 'SERVICE_REMINDER'
  | 'SECURITY_ALERT'
  | 'PASSWORD_RESET'
  | 'PHONE_VERIFICATION_CODE'
  | 'WELCOME';

export interface NotificationLog {
  id: string;
  eventType: NotificationEventType;
  recipientName: string;
  recipientPhone: string;
  recipientEmail?: string;
  channel: NotificationChannel;
  status: NotificationStatus;
  title: string;
  message: string;
  orderId?: string;
  orderCode?: string;
  merchantId?: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
  deliveredAt?: string;
  errorMessage?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariations: { [key: string]: string };
  selectedModality: 'DELIVERY' | 'RETIRADA' | 'EXPERIMENTAÇÃO';
}

export interface CarouselSlide {
  id: string;
  imageUrl: string;
  title: string;
  subtitle?: string;
  linkUrl?: string;
  actionText?: string;
  badge?: string;
  merchantId?: string;
  merchantName?: string;
  accentColor?: string;
}

export interface InterCategoryBanner {
  id: string;
  title: string;
  targetCategoryAfter: string; // ID of category it is displayed after (e.g. 'gastronomia', 'moda')
  slides: CarouselSlide[]; // Exactly 3 or more slides for autoplay
  autoplayIntervalSeconds: number; // default 4
  sponsorMerchantId?: string;
  sponsorMerchantName?: string;
  adSpaceId?: string;
  status: 'active' | 'paused' | 'draft';
  createdAt: string;
}

export type AdSpaceType = 'HERO_TOP' | 'INTER_CATEGORY' | 'FOOTER_BANNER' | 'CATEGORY_SPONSOR' | 'SEARCH_FEATURED';
export type AdCommercialType = 'DIRECT_SALE' | 'AUCTION';
export type AdSpaceStatus = 'AVAILABLE' | 'IN_AUCTION' | 'SOLD' | 'PAUSED';

export interface AuctionBid {
  id: string;
  merchantId: string;
  merchantName: string;
  bidAmount: number;
  timestamp: string;
  status: 'HIGHEST' | 'OUTBID' | 'ACCEPTED' | 'REJECTED';
  notes?: string;
}

export interface AdSpace {
  id: string;
  name: string;
  locationDescription: string; // Ex: "Banner Full-Width Entre Gastronomia e Moda"
  type: AdSpaceType;
  dimensions: string; // Ex: "1200x350 Full-Width (3 Slides Carrossel)"
  commercialType: AdCommercialType;
  status: AdSpaceStatus;
  fixedPricePerWeek?: number;
  fixedPricePerMonth?: number;
  // Auction fields:
  minimumBid?: number;
  currentHighestBid?: number;
  currentWinnerMerchantId?: string;
  currentWinnerMerchantName?: string;
  auctionEndDate?: string;
  bids?: AuctionBid[];
  // Active sponsor linkage:
  linkedBannerId?: string;
  activeMerchantId?: string;
  activeMerchantName?: string;
  impressionsCount: number;
  clicksCount: number;
  revenueTotal: number;
}

export interface NavMenuItem {
  id: string;
  label: string;
  target: string; // 'home', 'categories', 'gastronomia', 'moda', 'services', 'vender'
  iconName?: string;
  isExternal?: boolean;
  isVisible: boolean;
  badge?: string;
  order: number;
}

export interface FrontendCustomization {
  // Header
  siteTitle: string;
  siteSubtitle: string;
  logoLetter: string;
  logoImageUrl?: string;
  topAnnouncementText: string;
  topAnnouncementActive: boolean;
  topAnnouncementLink?: string;
  headerCtaText: string;
  headerCtaLink: string;
  
  // Navigation & Menus
  navMenuItems: NavMenuItem[];
  
  // Home & Categories Display
  categoryProductsLimit: number; // default 24
  categoryBlockSize: number; // default 4
  enabledCategoryIds: string[];
  categoryOrder: string[];
  enableInterCategoryBanners: boolean;
  
  // Merchant Posting Governance
  merchantPostingPolicy: 'FREE' | 'MODERATED' | 'PAID_SUBSCRIPTION';
  maxProductsPerMerchant: number;
  allowMerchantHighlightAuction: boolean;
  
  // Footer
  footerAboutText: string;
  footerSupportPhone: string;
  footerSupportEmail: string;
  footerSupportWhatsApp: string;
  footerAddress: string;
  footerCopyrightText: string;
  footerSocialInstagram?: string;
  footerSocialFacebook?: string;
  footerSocialWhatsApp?: string;
  footerCol1Title: string;
  footerCol2Title: string;
  footerCol3Title: string;
}

// ==========================================
// AVALIAÇÕES MÚTUAS & POLÍTICA DE REPUTAÇÃO
// ==========================================

export interface CustomerReviewCriteria {
  quality: number; // 1-5 Qualidade do produto ou serviço prestado
  punctuality: number; // 1-5 Pontualidade na entrega / agendamento / prazo
  service: number; // 1-5 Atendimento, educação e esclarecimento de dúvidas
  costBenefit: number; // 1-5 Relação custo-benefício
}

export interface CustomerToMerchantReview {
  id: string;
  orderId: string;
  orderCode: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  merchantId: string;
  merchantName: string;
  targetType: 'LOJA' | 'PRESTADOR_SERVICO';
  rating: number; // Média 1 a 5 estrelas
  criteria: CustomerReviewCriteria;
  comment: string;
  tags?: string[]; // Ex: ["Entrega Rápida", "Produto Impecável", "Atendimento Nota 10", "Preço Justo", "Profissional Experiente"]
  recommend: boolean;
  photos?: string[];
  merchantReply?: {
    replyText: string;
    repliedAt: string;
    merchantAuthorName: string;
  };
  verifiedPurchase: boolean;
  status: 'active' | 'reported' | 'moderated';
  createdAt: string;
}

export interface MerchantReviewBehaviorCriteria {
  punctuality: number; // 1-5 Pontualidade no recebimento/retirada/atendimento
  communication: number; // 1-5 Cordialidade e clareza na comunicação
  paymentAndAgreements: number; // 1-5 Cumprimento dos combinados de pagamento e retirada
  careAndRespect: number; // 1-5 Cuidado com produtos no provador / respeito ao profissional
}

export interface MerchantToCustomerReview {
  id: string;
  orderId: string;
  orderCode: string;
  merchantId: string;
  merchantName: string;
  userId: string;
  userName: string;
  customerPhone?: string;
  rating: number; // 1 a 5 estrelas
  behaviorCriteria: MerchantReviewBehaviorCriteria;
  comment: string;
  behaviorTags: string[]; // Ex: ["Cliente Pontual", "Excelente Comunicação", "Retirou no Prazo", "Pagamento Imediato", "Cuidado no Provador VIP", "Recomendo para outros Lojistas"]
  recommendForOtherMerchants: boolean;
  incidentReported?: boolean; // Caso tenha havido descumprimento grave de política (no-show, avaria)
  incidentDetails?: string;
  createdAt: string;
}

export interface CustomerReputationSummary {
  userId: string;
  userName: string;
  averageScore: number; // 1.0 a 5.0
  totalEvaluations: number;
  punctualityScore: number;
  communicationScore: number;
  paymentScore: number;
  careScore: number;
  recommendationPercentage: number; // % dos lojistas que recomendam
  badges: string[]; // Ex: ["Cliente 5 Estrelas", "Pagador Pontual", "VIP Verificado"]
  reviews: MerchantToCustomerReview[];
}

